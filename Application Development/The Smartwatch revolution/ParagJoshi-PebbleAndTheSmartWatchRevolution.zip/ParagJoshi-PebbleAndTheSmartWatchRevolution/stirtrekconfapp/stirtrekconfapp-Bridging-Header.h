//
//  stirtrekconfapp-Bridging-Header.h
//  stirtrekconfapp
//
//  Created by PARAG JOSHI on 4/7/15.
//  Copyright (c) 2015 APJ Endeavor LLC. All rights reserved.
//

#ifndef stirtrekconfapp_stirtrekconfapp_Bridging_Header_h
#define stirtrekconfapp_stirtrekconfapp_Bridging_Header_h

#import <PebbleKit/PebbleKit.h>

#endif
