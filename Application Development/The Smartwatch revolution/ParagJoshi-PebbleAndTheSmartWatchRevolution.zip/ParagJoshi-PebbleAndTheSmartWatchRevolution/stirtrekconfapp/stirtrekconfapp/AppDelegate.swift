//
//  AppDelegate.swift
//  stirtrekconfapp
//
//  Created by PARAG JOSHI on 4/7/15.
//  Copyright (c) 2015 APJ Endeavor LLC. All rights reserved.
//

import UIKit


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate ,PBPebbleCentralDelegate{
    
    var window: UIWindow?
    var connectedWatch: PBWatch?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        // Override point for customization after application launch.
        
        PBPebbleCentral.defaultCentral().delegate = self
        
        var myAppUUIDbytes: uuid_t
        var myAppUUID = NSUUID(UUIDString: "Unique UUID here")!
        
        // data object with appropriate size:
        var data = NSMutableData(length: 16)
        // fill the bytes from the UUID:
        myAppUUID.getUUIDBytes(UnsafeMutablePointer(data!.mutableBytes))
        
        
        PBPebbleCentral.defaultCentral().appUUID = data
        
        
        
        /* ... */
        self.connectedWatch = PBPebbleCentral.defaultCentral().lastConnectedWatch()
        if let watch = self.connectedWatch
        {
            NSLog("Last connected watch: %@", watch)
            //Launch app
            
            if watch.connected
            {
                self.connectedWatch?.appMessagesLaunch({ (watch, error) -> Void in
                    if error != nil  {
                        NSLog("error: %@",error)
                    }
                    else {
                        NSLog("Success launching app")
                    }
                })
                
                
                self.connectedWatch?.appMessagesAddReceiveUpdateHandler({ (watch, update) -> Bool in
                    NSLog("Message received %@", update)
                    
                    utils.updateWatchDisplay()
                    
                    return true;
                })
                
                utils.updateWatchDisplay()
            }
            
        }
        /* ... */
        
        
        return true
    }
    
    func updateWatchDisplayLocal() {
        utils.updateWatchDisplay()
    }
    
    func pebbleCentral(central:PBPebbleCentral, watchDidConnect watch:PBWatch , isNew:Bool) {
        NSLog("Pebble connected: %@", watch.name)
        NSLog("Pebble serial number: %@", watch.serialNumber);
        self.connectedWatch = watch
        
        
        NSLog("Last connected watch: %@", watch)
        //Launch app
        
        self.connectedWatch?.appMessagesLaunch({ (watch, error) -> Void in
            if error != nil  {
                NSLog("error: %@",error)
            }
            else {
                NSLog("Success launching app")
            }
        })
        
        
        self.connectedWatch?.appMessagesAddReceiveUpdateHandler({ (watch, update) -> Bool in
            NSLog("Message received %@", update)
            
            utils.updateWatchDisplay()
            
            return true;
        })
    }
    
    func pebbleCentral(central:PBPebbleCentral, watchDidDisconnect watch:PBWatch) {
        NSLog("Pebble disconnected: %@", watch.name)
        
        if (self.connectedWatch == watch || watch.isEqual(self.connectedWatch)) {
            self.connectedWatch = nil
        }
    }
    
    
    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
        
    }
    
    func applicationWillEnterForeground(application: UIApplication) {
        utils.updateWatchDisplay()
        
    }
    
    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        
    }
    
    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    
}

