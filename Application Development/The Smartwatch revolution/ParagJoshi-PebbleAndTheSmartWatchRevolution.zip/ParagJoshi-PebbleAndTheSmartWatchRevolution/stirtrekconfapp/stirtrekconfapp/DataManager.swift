//
//  DataManager.swift
//  stirtrekconfapp
//
//  Created by PARAG JOSHI on 4/15/15.
//  Copyright (c) 2015 APJ Endeavor LLC. All rights reserved.
//

import Foundation


let StirTrekAppURL = "http://stirtrek.com/Feed/Json"


class DataManager {

    
    
    class func loadDataFromURL(url: NSURL, completion:(data: NSData?, error: NSError?) -> Void) {
        var session = NSURLSession.sharedSession()
        
        // Use NSURLSession to get data from an NSURL
        let loadDataTask = session.dataTaskWithURL(url, completionHandler: { (data: NSData!, response: NSURLResponse!, error: NSError!) -> Void in
            if let responseError = error {
                completion(data: nil, error: responseError)
            } else if let httpResponse = response as? NSHTTPURLResponse {
                if httpResponse.statusCode != 200 {
                    var statusError = NSError(domain:"com.yourcompanyname", code:httpResponse.statusCode, userInfo:[NSLocalizedDescriptionKey : "HTTP status code has unexpected value."])
                    completion(data: nil, error: statusError)
                } else {
                    completion(data: data, error: nil)
                }
            }
        })
        
        loadDataTask.resume()
    }

    class func getSessionDataFromStirTrekWithSuccess(success: ((sessionData: NSData!) -> Void)) {
        //1
        loadDataFromURL(NSURL(string: StirTrekAppURL)!, completion:{(data, error) -> Void in
            //2
            if let urlData = data {
                //3
                
                // Get the number 1 app using optional binding and NSJSONSerialization
                //1
                var parseError: NSError?
                let parsedObject: AnyObject? = NSJSONSerialization.JSONObjectWithData(urlData,
                    options: NSJSONReadingOptions.AllowFragments,
                    error:&parseError)
                
                
                //2
                if let conferenceData = parsedObject as? NSDictionary {
                    sessionsData = conferenceData
                    
                    var userdefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
                    
                    
             
                    var data = NSKeyedArchiver.archivedDataWithRootObject(sessionsData!)
                    userdefaults.setObject(data , forKey: "SessionData")
                    userdefaults.synchronize()
                    
                }
                
                success(sessionData: urlData)
            }
        })
    }

    
    
    


}