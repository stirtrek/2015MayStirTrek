//
//  FirstViewController.swift
//  stirtrekconfapp
//
//  Created by PARAG JOSHI on 4/7/15.
//  Copyright (c) 2015 APJ Endeavor LLC. All rights reserved.
//

import UIKit
import CoreData

class FirstViewController: UITableViewController, NSFetchedResultsControllerDelegate {
    
    var connectedWatch: PBWatch?
    
    var managedObjectContext: NSManagedObjectContext? = nil
    
    var timeSlotsSortedList:NSArray? = nil
    
    var favoritesMutableArray = NSMutableArray()
    
    var selectedSession: NSDictionary? = nil
    
    @IBOutlet var tableview: UITableView!
    
    var messageFrame = UIView()
    var activityIndicator = UIActivityIndicatorView()
    var strLabel = UILabel()
    
    func progressBarDisplayer(msg:String, _ indicator:Bool ) {
        println(msg)
        strLabel = UILabel(frame: CGRect(x: 50, y: 0, width: 200, height: 50))
        strLabel.text = msg
        strLabel.textColor = UIColor.whiteColor()
        messageFrame = UIView(frame: CGRect(x: view.frame.midX - 90, y: view.frame.midY - 25 , width: 180, height: 50))
        messageFrame.layer.cornerRadius = 15
        messageFrame.backgroundColor = UIColor(white: 0, alpha: 0.7)
        if indicator {
            activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.White)
            activityIndicator.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
            activityIndicator.startAnimating()
            messageFrame.addSubview(activityIndicator)
        }
        messageFrame.addSubview(strLabel)
        view.addSubview(messageFrame)
    }

    
    func refreshData(recognizer: UITapGestureRecognizer) {
        DataManager.getSessionDataFromStirTrekWithSuccess { (sessionData) -> Void in
            
//            var userDefaults = NSUserDefaults.standardUserDefaults()

             var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
            
            userDefaults.setValue(true, forKey: "ReloadSpeakersView")
            userDefaults.setValue(true, forKey: "ReloadSessionsView")
            userDefaults.setValue(true, forKey: "ReloadTracksView")
            userDefaults.setValue(true, forKey: "ReloadSponsorsView")
            
            self.tableview.reloadData()
        }
        
    }
    
    func markFavorites(recognizer: UILongPressGestureRecognizer) {
        
        if (recognizer.state == UIGestureRecognizerState.Ended) {
            NSLog("UIGestureRecognizerStateEnded");
            //Do Whatever You want on End of Gesture
            
            
            var point =  recognizer.locationInView(self.tableview)
            
            var indexPath: NSIndexPath? = self.tableView.indexPathForRowAtPoint(point)
            
            if  indexPath == nil {
                NSLog("long press on table view but not on a row");
            } else {
                var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
                
                
                
                if let favoritesData: AnyObject = userDefaults.objectForKey("FavoritesData")
                {
                    // We have cached favorites
                    if let  favoritesMutableArrayFromCache = NSKeyedUnarchiver.unarchiveObjectWithData(favoritesData as! NSData) as? NSMutableArray{
                        favoritesMutableArray = favoritesMutableArrayFromCache
                        
                    }
                }
                
                
                var selected = false
                
                if let sessions = sessionsData {
                    if let timeSlotList = timeSlotsSortedList{
                        
                        if let timeSlot = timeSlotList[indexPath!.section]["Id"] as? Int
                        {
                            if let sessionArray = sessions["Sessions"] as? NSArray{
                                
                                let resultPredicate = NSPredicate(format: "TimeSlotId = \(timeSlot)")
                                
                                var filteredSessions = sessionArray.filteredArrayUsingPredicate(resultPredicate)
                                
                                var selectedSessionId = filteredSessions[indexPath!.row]["Id"] as? Int
                                
                                if let selectedSessionIdValue  = selectedSessionId
                                {
                                    if favoritesMutableArray.containsObject(selectedSessionIdValue)
                                    {
                                        favoritesMutableArray.removeObject(selectedSessionIdValue)
                                        //Change background color of cell to blue
                                        
                                        if let selectedCell = self.tableview.cellForRowAtIndexPath(indexPath!)
                                        {
                                            selectedCell.textLabel?.textColor = UIColor.blueColor()
                                            selectedCell.detailTextLabel?.textColor = UIColor.blueColor()
                                        }
                                        selected = false
                                    }
                                    else
                                    {
                                        favoritesMutableArray.addObject(selectedSessionIdValue)
                                        //Change background color of cell to blue
                                        
                                        if let selectedCell = self.tableview.cellForRowAtIndexPath(indexPath!)
                                        {
                                            selectedCell.textLabel?.textColor = UIColor.blackColor()
                                            selectedCell.detailTextLabel?.textColor = UIColor.blackColor()
                                        }
                                        selected = true
                                    }
                                    
                                    var data = NSKeyedArchiver.archivedDataWithRootObject(favoritesMutableArray)
                                    userDefaults.setObject(data , forKey: "FavoritesData")
                                    userDefaults.synchronize()
                                    
                                    self.tableview.reloadRowsAtIndexPaths([indexPath!], withRowAnimation: UITableViewRowAnimation.None)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        progressBarDisplayer("Loading Data", true)
        
        var  twoFingerTap = UITapGestureRecognizer(target: self , action: Selector("refreshData:"))
        twoFingerTap.numberOfTouchesRequired = 2
        
        self.tableView.addGestureRecognizer(twoFingerTap)
        
        
        var longPressGesture = UILongPressGestureRecognizer(target: self, action: Selector("markFavorites:"))
        self.tableview.addGestureRecognizer(longPressGesture)
        
        
        self.navigationController?.navigationBar.topItem?.title = "Sessions"
        
        
        
        var userdefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
        
        
        if let favoritesData: AnyObject = userdefaults.objectForKey("FavoritesData")
        {
            // We have cached favorites
            if let  favoritesMutableArrayFromCache = NSKeyedUnarchiver.unarchiveObjectWithData(favoritesData as! NSData) as? NSMutableArray{
                favoritesMutableArray = favoritesMutableArrayFromCache
                
            }
        }
        
        
        if let sessionsCachedData: AnyObject = userdefaults.objectForKey("SessionData")
        {
            // We have cached data
            if sessionsData == nil
            {
                if let  sessionsDataDictionary = NSKeyedUnarchiver.unarchiveObjectWithData(sessionsCachedData as! NSData) as? NSDictionary{
                    sessionsData = sessionsDataDictionary
                }
            }
            
            if let sessions = sessionsData {
                
                if let timeSlots = sessions["TimeSlots"] as? NSArray {
                    
                    self.timeSlotsSortedList = timeSlots.sortedArrayUsingComparator({ (dict1, dict2) -> NSComparisonResult in
                        let  dateFormatter = NSDateFormatter()
                        dateFormatter.dateFormat = "hh:mm a"
                        
                        if let t1 = dict1 as? NSDictionary
                        {
                            if let t2 = dict2 as? NSDictionary
                            {
                                if let date1 = dateFormatter.dateFromString(t1["StartTime"] as! String)
                                {
                                  if let date2 = dateFormatter.dateFromString(t2["StartTime"] as! String)
                                  {
                        
                                        return date1.compare(date2)
                                    }
                                }
                            }
                        }
                        return NSComparisonResult.OrderedSame
                    })
                }
            }
            
            utils.updateWatchDisplay()
            
            dispatch_async(dispatch_get_main_queue()) {
                self.messageFrame.removeFromSuperview()
            }
            
            self.tableview.reloadData()
        }
        else
        {
            DataManager.getSessionDataFromStirTrekWithSuccess { (sessionData) -> Void in
                
                //create sorted timeslots dictionary
                
                if let sessions = sessionsData {
                    
                    if let timeSlots = sessions["TimeSlots"] as? NSArray {
                        
                        self.timeSlotsSortedList = timeSlots.sortedArrayUsingComparator({ (dict1, dict2) -> NSComparisonResult in
                            let  dateFormatter = NSDateFormatter()
                            dateFormatter.dateFormat = "hh:mm a"
                            
                            let t1 = dict1 as! NSDictionary
                            let t2 = dict2 as! NSDictionary
                            let date1 = dateFormatter.dateFromString(t1["StartTime"] as! String)
                            let date2 = dateFormatter.dateFromString(t2["StartTime"] as! String)
                            
                            return date1!.compare(date2!)
                        })
                    }
                }
                
                // Set key to false if true as we have already loaded fresh data
                var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
                
                
                if let reloadThisView: AnyObject  = userDefaults.valueForKey("ReloadSessionsView")
                {
                    if reloadThisView as! Bool  == true
                    {
                        userDefaults.setValue(false, forKey: "ReloadSessionsView")
                        
                    }
                }
                
                utils.updateWatchDisplay()
                
                
                self.tableview.reloadData()
                
                dispatch_async(dispatch_get_main_queue()) {
                    self.messageFrame.removeFromSuperview()
                }
                
            }
        }
    }
    
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        self.performSegueWithIdentifier("selectedSessionSegue", sender: self)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        
        NSLog("Segue name \(segue.identifier)")
        
        
        if let indexPath  = self.tableview.indexPathForSelectedRow()
        {
            
            if let sessions = sessionsData {
                
                if let timeSlotList = timeSlotsSortedList{
                    
                    if let timeSlot = timeSlotList[indexPath.section]["Id"] as? Int
                    {
                        if let sessionArray = sessions["Sessions"] as? NSArray{
                            
                            let resultPredicate = NSPredicate(format: "TimeSlotId = \(timeSlot)")
                            
                            var filteredSessions = sessionArray.filteredArrayUsingPredicate(resultPredicate)
                            selectedSession = filteredSessions[indexPath.row] as? NSDictionary
                            
                        }
                    }
                }
            }
            
            if let  destinationVC = segue.destinationViewController as? SessionDetailsViewController
            {
                destinationVC.selectedSession = selectedSession
            }
        }
    }
    
    override func viewDidAppear(animated: Bool) {
        var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
        
        if let reloadThisView: AnyObject  = userDefaults.valueForKey("ReloadSessionsView")
        {
            if reloadThisView as! Bool  == true
            {
                if let sessionsCachedData: AnyObject = userDefaults.objectForKey("SessionData")
                {
                    // We have cached data
                    if sessionsData == nil
                    {
                        if let  sessionsDataDictionary = NSKeyedUnarchiver.unarchiveObjectWithData(sessionsCachedData as! NSData) as? NSDictionary{
                            sessionsData = sessionsDataDictionary
                        }
                    }
                    
                    if let sessions = sessionsData {
                        
                        if let timeSlots = sessions["TimeSlots"] as? NSArray {
                            
                            self.timeSlotsSortedList = timeSlots.sortedArrayUsingComparator({ (dict1, dict2) -> NSComparisonResult in
                                let  dateFormatter = NSDateFormatter()
                                dateFormatter.dateFormat = "hh:mm a"
                                
                                let t1 = dict1 as! NSDictionary
                                let t2 = dict2 as! NSDictionary
                                let date1 = dateFormatter.dateFromString(t1["StartTime"] as! String)
                                let date2 = dateFormatter.dateFromString(t2["StartTime"] as! String)
                                
                                return date1!.compare(date2!)
                            })
                        }
                    }
                    
                    //self.tableview.reloadData()
                }
                userDefaults.setValue(false, forKey: "ReloadSessionsView")
            }
        }
        if let favoritesData: AnyObject = userDefaults.objectForKey("FavoritesData")
        {
            // We have cached favorites
            if let  favoritesMutableArrayFromCache = NSKeyedUnarchiver.unarchiveObjectWithData(favoritesData as! NSData) as? NSMutableArray{
                favoritesMutableArray = favoritesMutableArrayFromCache
                
            }
        }

        self.tableview.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Table View
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        //        if let sessions = sessionsData {
        //            if let timeSlots = sessions["TimeSlots"] as! NSArray? {
        //                return timeSlots.count
        //            }
        //        }
        
        if let timeSlotList = timeSlotsSortedList
        {
            return timeSlotList.count
        }
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let sessions = sessionsData {
            if let timeSlotList = timeSlotsSortedList
            {
                
                if let timeSlot = timeSlotList[section]["Id"] as? Int
                {
                    if let sessionArray = sessions["Sessions"] as? NSArray{
                        
                        let resultPredicate = NSPredicate(format: "TimeSlotId = \(timeSlot)")
                        
                        var countOfData = sessionArray.filteredArrayUsingPredicate(resultPredicate).count
                        
                        return countOfData
                    }
                }
            }
        }
        
        return 0
    }
    
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        //        if let sessions = sessionsData {
        //            if let timeSlots = sessions["TimeSlots"] as! NSArray? {
        //                if let timeSlot: NSDictionary = timeSlots[section] as? NSDictionary
        //                {
        //                    if let startTime = timeSlot["StartTime"] as! String?
        //                    {
        //                        if let endTime = timeSlot["EndTime"] as! String?
        //                        {
        //                                return "\(startTime) - \(endTime)"
        //                        }
        //                    }
        //                }
        //            }
        //        }
        
        
        if let timeSlotList = timeSlotsSortedList
        {
            if let timeSlot: NSDictionary = timeSlotList[section] as? NSDictionary
            {
                if let startTime = timeSlot["StartTime"] as! String?
                {
                    if let endTime = timeSlot["EndTime"] as! String?
                    {
                        return "\(startTime) - \(endTime)"
                    }
                }
            }
            
        }
        return ""
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell =  UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: nil)  //tableView.dequeueReusableCellWithIdentifier("TextCell", forIndexPath: indexPath) as! UITableViewCell
        self.configureCell(cell, atIndexPath: indexPath)
        return cell
    }
    
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return false
    }
    
    func configureCell(cell: UITableViewCell, atIndexPath indexPath: NSIndexPath) {
        
        var sessionName : String?
        var sessionAbstract : String?
        
        if let sessions = sessionsData {
            
            if let timeSlotList = timeSlotsSortedList{
                
                if let timeSlot = timeSlotList[indexPath.section]["Id"] as? Int
                {
                    if let sessionArray = sessions["Sessions"] as? NSArray{
                        
                        let resultPredicate = NSPredicate(format: "TimeSlotId = \(timeSlot)")
                        
                        var filteredSessions = sessionArray.filteredArrayUsingPredicate(resultPredicate)
                        
                        sessionName = filteredSessions[indexPath.row]["Name"] as? String
                        
                        if let sessionNameValue = sessionName
                        {
                            if(sessionNameValue.lowercaseString == "breakfast" || sessionNameValue.lowercaseString == "lunch" || sessionNameValue.lowercaseString == "avengers: age of ultron")
                            {
                                cell.accessoryType = UITableViewCellAccessoryType.None
                                cell.selectionStyle = UITableViewCellSelectionStyle.None
                                cell.userInteractionEnabled = false
                            }
                            else
                            {
                                cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
                            }
                        }
                        
                        
                        
                        if let tracks = sessions["Tracks"] as? NSArray {
                            if let trackId = filteredSessions[indexPath.row]["TrackId"] as? Int
                            {
                                
                                let resultPredicatetimeSlot = NSPredicate(format: "Id = \(trackId)")
                                
                                var filteredTrackArray = tracks.filteredArrayUsingPredicate(resultPredicatetimeSlot)
                                
                                if filteredTrackArray.count > 0
                                {
                                    if let track: NSDictionary = filteredTrackArray[0] as? NSDictionary
                                    {
                                        if let startTime = track["Name"] as! String?
                                        {
                                            if let endTime = track["Location"] as! String?
                                            {
                                                sessionAbstract =  "\(startTime) - \(endTime)"
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        //sessionAbstract = filteredSessions[indexPath.row]["Abstract"] as? String
                        
                        
                        var selectedSessionId = filteredSessions[indexPath.row]["Id"] as? Int
                        
                        if let selectedSessionIdValue  = selectedSessionId
                        {
                            if favoritesMutableArray.containsObject(selectedSessionIdValue)
                            {
                                //Change background color of cell to blue
                                cell.textLabel?.textColor = UIColor.blueColor()
                                cell.detailTextLabel?.textColor = UIColor.blueColor()
                                
                            }
                            else
                            {
                                cell.textLabel?.textColor = UIColor.blackColor()
                                cell.detailTextLabel?.textColor = UIColor.blackColor()
                                
                            }
                            
                        }
                        
                    }
                }
            }
        }
        
        
        cell.textLabel!.text = sessionName
        if sessionAbstract != nil
        {
            cell.detailTextLabel!.text = sessionAbstract
        }else{
            cell.detailTextLabel!.text = ""
        }
    }
    
    
    /*
    // Implementing the above methods to update the table view in response to individual changes may have performance implications if a large number of changes are made simultaneously. If this proves to be an issue, you can instead just implement controllerDidChangeContent: which notifies the delegate that all section and object changes have been processed.
    
    func controllerDidChangeContent(controller: NSFetchedResultsController) {
    // In the simplest, most efficient, case, reload the table view.
    self.tableView.reloadData()
    }
    */
    
    
}

