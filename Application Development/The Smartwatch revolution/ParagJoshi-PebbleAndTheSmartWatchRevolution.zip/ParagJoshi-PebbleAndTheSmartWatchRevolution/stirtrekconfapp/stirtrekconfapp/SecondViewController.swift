//
//  SecondViewController.swift
//  stirtrekconfapp
//
//  Created by PARAG JOSHI on 4/7/15.
//  Copyright (c) 2015 APJ Endeavor LLC. All rights reserved.
//

import UIKit

class SecondViewController: UITableViewController {

    @IBOutlet var tableview: UITableView!
    var favoritesMutableArray = NSMutableArray()

    var messageFrame = UIView()
    var activityIndicator = UIActivityIndicatorView()
    var strLabel = UILabel()
    
    func progressBarDisplayer(msg:String, _ indicator:Bool ) {
        println(msg)
        strLabel = UILabel(frame: CGRect(x: 50, y: 0, width: 200, height: 50))
        strLabel.text = msg
        strLabel.textColor = UIColor.whiteColor()
        messageFrame = UIView(frame: CGRect(x: view.frame.midX - 90, y: view.frame.midY - 25 , width: 180, height: 50))
        messageFrame.layer.cornerRadius = 15
        messageFrame.backgroundColor = UIColor(white: 0, alpha: 0.7)
        if indicator {
            activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.White)
            activityIndicator.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
            activityIndicator.startAnimating()
            messageFrame.addSubview(activityIndicator)
        }
        messageFrame.addSubview(strLabel)
        view.addSubview(messageFrame)
    }
    
    func refreshData(recognizer: UITapGestureRecognizer) {
        DataManager.getSessionDataFromStirTrekWithSuccess { (sessionData) -> Void in
            
            var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
            
            userDefaults.setValue(true, forKey: "ReloadSpeakersView")
            userDefaults.setValue(true, forKey: "ReloadSessionsView")
            userDefaults.setValue(true, forKey: "ReloadTracksView")
            userDefaults.setValue(true, forKey: "ReloadSponsorsView")
            
            self.tableview.reloadData()
        }
        
    }

    
    func markFavorites(recognizer: UILongPressGestureRecognizer) {
        
        if (recognizer.state == UIGestureRecognizerState.Ended) {
            NSLog("UIGestureRecognizerStateEnded");
            //Do Whatever You want on End of Gesture
            
            
            var point =  recognizer.locationInView(self.tableview)
            
            var indexPath: NSIndexPath? = self.tableView.indexPathForRowAtPoint(point)
            
            if  indexPath == nil {
                NSLog("long press on table view but not on a row");
            } else {
                var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
                
                
                
                if let favoritesData: AnyObject = userDefaults.objectForKey("FavoritesData")
                {
                    // We have cached favorites
                    if let  favoritesMutableArrayFromCache = NSKeyedUnarchiver.unarchiveObjectWithData(favoritesData as! NSData) as? NSMutableArray{
                        favoritesMutableArray = favoritesMutableArrayFromCache
                        
                    }
                }
                
                
                var selected = false
                
                if let sessions = sessionsData {
                    
                    if let timeSlots = sessions["Tracks"] as? NSArray {
                        
                        if let timeSlot = timeSlots[indexPath!.section]["Id"] as? Int
                        {
                            if let sessionArray = sessions["Sessions"] as? NSArray{
                                
                                let resultPredicate = NSPredicate(format: "TrackId = \(timeSlot)")
                                
                                var filteredSessions = sessionArray.filteredArrayUsingPredicate(resultPredicate)
                                
                                var selectedSessionId = filteredSessions[indexPath!.row]["Id"] as? Int
                
                                
                                if let selectedSessionIdValue  = selectedSessionId
                                {
                                    if favoritesMutableArray.containsObject(selectedSessionIdValue)
                                    {
                                        favoritesMutableArray.removeObject(selectedSessionIdValue)
                                        //Change background color of cell to blue
                                        
                                        if let selectedCell = self.tableview.cellForRowAtIndexPath(indexPath!)
                                        {
                                            selectedCell.textLabel?.textColor = UIColor.blueColor()
                                            selectedCell.detailTextLabel?.textColor = UIColor.blueColor()
                                        }
                                        selected = false
                                    }
                                    else
                                    {
                                        favoritesMutableArray.addObject(selectedSessionIdValue)
                                        //Change background color of cell to blue
                                        
                                        if let selectedCell = self.tableview.cellForRowAtIndexPath(indexPath!)
                                        {
                                            selectedCell.textLabel?.textColor = UIColor.blackColor()
                                            selectedCell.detailTextLabel?.textColor = UIColor.blackColor()
                                        }
                                        selected = true
                                    }
                                    
                                    var data = NSKeyedArchiver.archivedDataWithRootObject(favoritesMutableArray)
                                    userDefaults.setObject(data , forKey: "FavoritesData")
                                    userDefaults.synchronize()
                                    
                                    self.tableview.reloadRowsAtIndexPaths([indexPath!], withRowAnimation: UITableViewRowAnimation.None)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        progressBarDisplayer("Loading Data", true)
        
        var  twoFingerTap = UITapGestureRecognizer(target: self , action: Selector("refreshData:"))
        twoFingerTap.numberOfTouchesRequired = 2
        
        self.tableView.addGestureRecognizer(twoFingerTap)

        
        var longPressGesture = UILongPressGestureRecognizer(target: self, action: Selector("markFavorites:"))
        self.tableview.addGestureRecognizer(longPressGesture)
        
        self.navigationController?.navigationBar.topItem?.title = "Tracks"

        
        var userdefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
        
        
        if let favoritesData: AnyObject = userdefaults.objectForKey("FavoritesData")
        {
            // We have cached favorites
            if let  favoritesMutableArrayFromCache = NSKeyedUnarchiver.unarchiveObjectWithData(favoritesData as! NSData) as? NSMutableArray{
                favoritesMutableArray = favoritesMutableArrayFromCache
                
            }
        }
        
        
        if let sessionsCachedData: AnyObject = userdefaults.objectForKey("SessionData")
        {
            // We have cached data
            if sessionsData == nil
            {
                if let  sessionsDataDictionary = NSKeyedUnarchiver.unarchiveObjectWithData(sessionsCachedData as! NSData) as? NSDictionary{
                    sessionsData = sessionsDataDictionary
                }
            }
            //self.tableView.reloadData()

        }
        else
        {
            DataManager.getSessionDataFromStirTrekWithSuccess { (sessionData) -> Void in
                
                // Set key to false if true as we have already loaded fresh data
                var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
                
                
                if let reloadThisView: AnyObject  = userDefaults.valueForKey("ReloadTracksView")
                {
                    if reloadThisView as! Bool  == true
                    {
                        userDefaults.setValue(false, forKey: "ReloadTracksView")
                        
                    }
                }

                utils.updateWatchDisplay()
     
                
                //self.tableview.reloadData()
            
            }
        }

    }
    
    
    override func viewDidAppear(animated: Bool) {
        var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
        
        if let reloadThisView: AnyObject  = userDefaults.valueForKey("ReloadTracksView")
        {
            if reloadThisView as! Bool  == true
            {
                //self.tableview.reloadData()
                userDefaults.setValue(false, forKey: "ReloadTracksView")
            }
        }
        
        if let favoritesData: AnyObject = userDefaults.objectForKey("FavoritesData")
        {
            // We have cached favorites
            if let  favoritesMutableArrayFromCache = NSKeyedUnarchiver.unarchiveObjectWithData(favoritesData as! NSData) as? NSMutableArray{
                favoritesMutableArray = favoritesMutableArrayFromCache
                
            }
        }

        self.tableview.reloadData()
        
        dispatch_async(dispatch_get_main_queue()) {
            self.messageFrame.removeFromSuperview()
        }
        
        self.tableview.reloadData()
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    // MARK: - Table View
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        if let sessions = sessionsData {
            if let timeSlots = sessions["Tracks"] as! NSArray? {
                return timeSlots.count
            }
        }
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let sessions = sessionsData {
            
            if let timeSlots = sessions["Tracks"] as? NSArray {
                
                if let timeSlot = timeSlots[section]["Id"] as? Int
                {
                    if let sessionArray = sessions["Sessions"] as? NSArray{
                        
                        let resultPredicate = NSPredicate(format: "TrackId = \(timeSlot)")
                        
                        var countOfData = sessionArray.filteredArrayUsingPredicate(resultPredicate).count
                        
                        return countOfData
                    }
                }
            }
        }
        
        return 0
    }
    
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        if let sessions = sessionsData {
            if let timeSlots = sessions["Tracks"] as! NSArray? {
                if let timeSlot: NSDictionary = timeSlots[section] as? NSDictionary
                {
                    if let trackName = timeSlot["Name"] as! String?
                    {
                        if let location = timeSlot["Location"] as! String?
                        {
                            return "\(trackName) - \(location)"
                        }
                    }
                }
            }
        }
        return ""
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("TrackCellIdentifier", forIndexPath: indexPath) as! UITableViewCell
        self.configureCell(cell, atIndexPath: indexPath)
        return cell
    }
    
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return false
    }
    
    
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        self.performSegueWithIdentifier("selectedSessionSegue", sender: self)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        
        NSLog("Segue name \(segue.identifier)")
        
        
        if let indexPath  = self.tableview.indexPathForSelectedRow()
        {
            if let sessions = sessionsData {
                
                if let timeSlots = sessions["Tracks"] as? NSArray {
                    
                    if let timeSlot = timeSlots[indexPath.section]["Id"] as? Int
                    {
                        if let sessionArray = sessions["Sessions"] as? NSArray{
                            
                            let resultPredicate = NSPredicate(format: "TrackId = \(timeSlot)")
                            
                            var filteredSessions = sessionArray.filteredArrayUsingPredicate(resultPredicate)
                            
                            var selectedSession = filteredSessions[indexPath.row] as? NSDictionary
                            
                            if let  destinationVC = segue.destinationViewController as? SessionDetailsViewController
                            {
                                destinationVC.selectedSession = selectedSession
                            }
                        }
                    }
                }
            }
        }
    }
    
    func configureCell(cell: UITableViewCell, atIndexPath indexPath: NSIndexPath) {
        
        var sessionName : String?
        var sessionAbstract : String?
        
        if let sessions = sessionsData {
            
            if let timeSlots = sessions["Tracks"] as? NSArray {
                
                if let timeSlot = timeSlots[indexPath.section]["Id"] as? Int
                {
                    if let sessionArray = sessions["Sessions"] as? NSArray{
                        
                        let resultPredicate = NSPredicate(format: "TrackId = \(timeSlot)")
                        
                        var filteredSessions = sessionArray.filteredArrayUsingPredicate(resultPredicate)
                        
                        sessionName = filteredSessions[indexPath.row]["Name"] as? String
                        sessionAbstract = filteredSessions[indexPath.row]["Abstract"] as? String
                        
                        
                        var selectedSessionId = filteredSessions[indexPath.row]["Id"] as? Int
                        
                        if let selectedSessionIdValue  = selectedSessionId
                        {
                            if favoritesMutableArray.containsObject(selectedSessionIdValue)
                            {
                                //Change background color of cell to blue
                                cell.textLabel?.textColor = UIColor.blueColor()
                                cell.detailTextLabel?.textColor = UIColor.blueColor()
                                
                            }
                            else
                            {
                                cell.textLabel?.textColor = UIColor.blackColor()
                                cell.detailTextLabel?.textColor = UIColor.blackColor()
                                
                            }
                            
                        }

                    }
                }
            }
        }
        
        
        cell.textLabel!.text = sessionName
        cell.detailTextLabel!.text = sessionAbstract
    }

}

