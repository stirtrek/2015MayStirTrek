//
//  SessionDetailsViewController.swift
//  stirtrekconfapp
//
//  Created by PARAG JOSHI on 4/18/15.
//  Copyright (c) 2015 APJ Endeavor LLC. All rights reserved.
//

import Foundation
import UIKit

class SessionDetailsViewController: UITableViewController {
    
    @IBOutlet var tableview: UITableView!
    
    var selectedSession: NSDictionary?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        self.tableView.estimatedRowHeight = 100
        self.tableView.rowHeight = UITableViewAutomaticDimension
        var tblView =  UIView(frame: CGRectZero)
        self.tableView.tableFooterView = tblView
        self.tableview.reloadData()
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Table View
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 2
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section{
        case 0: return 4
        case 1: return 1
        default: return 0
        }
    }
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section{
        case 0: return "Speaker and Session Information"
        case 1: return "Abstract"
        default: return ""
        }
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        switch indexPath.section{
        case 0:
            switch indexPath.row
            {
            case 0:
                let cell = tableView.dequeueReusableCellWithIdentifier("NameIdentifier", forIndexPath: indexPath) as! UITableViewCell
                
                var value = selectedSession!["Name"] as? String
                cell.detailTextLabel?.text = value
                return cell
                
            case 1:
                let cell = tableView.dequeueReusableCellWithIdentifier("TimeIdentifier", forIndexPath: indexPath) as! UITableViewCell
                if let sessions = sessionsData {
                    
                    if let timeSlots = sessions["TimeSlots"] as? NSArray {
                        
                        var timeSlot = selectedSession!["TimeSlotId"] as? Int
                        
                        let resultPredicate = NSPredicate(format: "Id = \(timeSlot!)")
                        
                        var filteredTimeSlotArray = timeSlots.filteredArrayUsingPredicate(resultPredicate)
                        
                        if filteredTimeSlotArray.count > 0
                        {
                             if let timeSlot: NSDictionary = filteredTimeSlotArray[0] as? NSDictionary
                            {
                                if let startTime = timeSlot["StartTime"] as! String?
                                {
                                    if let endTime = timeSlot["EndTime"] as! String?
                                    {
                                        cell.detailTextLabel?.text =  "\(startTime) - \(endTime)"
                                    }
                                }
                            }
                        }
                    }
                }

                return cell
                
            case 2:
                let cell = tableView.dequeueReusableCellWithIdentifier("SpeakerIdentifier", forIndexPath: indexPath) as! UITableViewCell
                
                var speakersText = ""
                
                if let speakerArray = selectedSession!["SpeakerIds"] as? NSArray
                {
                    
                    for speaker in speakerArray{
                        if !speakersText.isEmpty{
                            speakersText = speakersText + ", "
                        }
                        if let sessions = sessionsData {
                            
                            if let sessionArray = sessions["Speakers"] as? NSArray{
                                
                                let resultPredicate = NSPredicate(format: "Id = \(speaker)")
                                
                                var filteredArray = sessionArray.filteredArrayUsingPredicate(resultPredicate)
                                if filteredArray.count >= 1 {
                                    var name  = filteredArray[0]["Name"] as? String
                                    speakersText = speakersText + name!
                                }
                                
                                
                            }
                        }
                    }
                }
                
                
                cell.detailTextLabel?.text = speakersText
                return cell
                
            case 3:
                let cell = tableView.dequeueReusableCellWithIdentifier("TrackIdentifier", forIndexPath: indexPath) as! UITableViewCell
                
                
                
                if let sessions = sessionsData {
                    
                    if let timeSlots = sessions["Tracks"] as? NSArray {
                        
                        var timeSlot = selectedSession!["TrackId"] as? Int
                        
                        let resultPredicate = NSPredicate(format: "Id = \(timeSlot!)")
                        
                        var filteredTimeSlotArray = timeSlots.filteredArrayUsingPredicate(resultPredicate)
                        
                        if filteredTimeSlotArray.count > 0
                        {
                            if let timeSlot: NSDictionary = filteredTimeSlotArray[0] as? NSDictionary
                            {
                                if let startTime = timeSlot["Name"] as! String?
                                {
                                    if let endTime = timeSlot["Location"] as! String?
                                    {
                                        cell.detailTextLabel?.text =  "\(startTime) - \(endTime)"
                                    }
                                }
                            }
                        }
                    }
                }
                

                
                
                return cell
            default: return UITableViewCell .alloc()
            }
            
        case 1:
            switch indexPath.row
            {
            case 0:
                
                let cell = tableView.dequeueReusableCellWithIdentifier("AbstractIdentifier", forIndexPath: indexPath) as! UITableViewCell
                
                var value = selectedSession!["Abstract"] as? String
                
                //            if let scrollView  = cell.contentView.viewWithTag(10) as? UIScrollView
                //            {
                if let detailLabel  = cell.contentView.viewWithTag(1) as? UILabel
                {
                    detailLabel.text = value
                }
                //            }
                //cell.detailTextLabel?.text = value
                return cell
            default: return UITableViewCell .alloc()
            }
        
        default:  return UITableViewCell .alloc()
        }
    }
    
}
