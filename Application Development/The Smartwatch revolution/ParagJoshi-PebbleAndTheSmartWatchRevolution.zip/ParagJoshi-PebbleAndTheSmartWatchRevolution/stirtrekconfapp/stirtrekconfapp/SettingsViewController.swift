//
//  SettingsViewController.swift
//  stirtrekconfapp
//
//  Created by PARAG JOSHI on 4/16/15.
//  Copyright (c) 2015 APJ Endeavor LLC. All rights reserved.
//

import Foundation
import UIKit

class SettingsViewController: UITableViewController {
    
    @IBOutlet var tableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        var  twoFingerTap = UITapGestureRecognizer(target: self , action: Selector("refreshData:"))
        twoFingerTap.numberOfTouchesRequired = 2
        
        self.tableView.addGestureRecognizer(twoFingerTap)
        self.tableview.reloadData()
        
        
        
    }
    
    func refreshData(recognizer: UITapGestureRecognizer) {
        DataManager.getSessionDataFromStirTrekWithSuccess { (sessionData) -> Void in
            
            var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
            
            userDefaults.setValue(true, forKey: "ReloadSpeakersView")
            userDefaults.setValue(true, forKey: "ReloadSessionsView")
            userDefaults.setValue(true, forKey: "ReloadTracksView")
            userDefaults.setValue(true, forKey: "ReloadSponsorsView")
            
            
        }

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        switch indexPath.row
        {
            
        case 1: return 250
        case 2: return 150
        default: return 44
            
        }
    }
    
    // MARK: - Table View
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func switchIsChanged(mySwitch: UISwitch) {
        var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
        
        
        if mySwitch.on {
            userDefaults.setValue(true, forKey: "TutorialMode")
        } else {
            userDefaults.setValue(false, forKey: "TutorialMode")
        }
        
        utils.updateWatchDisplay()
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        switch indexPath.row
        {
        case 0:
            let cell = tableView.dequeueReusableCellWithIdentifier("PebbleWatchCellIdentifier", forIndexPath: indexPath) as! UITableViewCell
            cell.textLabel?.text="Pebble Watch"
            var connectedStatus = "Unknown"
            if let connectedWatch =  PBPebbleCentral.defaultCentral().lastConnectedWatch()
            {
                if connectedWatch.connected{
                    connectedStatus = "Connected"
                }
                else
                {
                     connectedStatus = "Disconnected"
                }
               
            }
            else
            {
                connectedStatus = "Disconnected"

            }
            
            cell.detailTextLabel?.text = connectedStatus
            return cell
            
        case 1:
            let cell = tableView.dequeueReusableCellWithIdentifier("TutorialModeCellIdentifier", forIndexPath: indexPath) as! UITableViewCell
            
            
            if let tutorialSwitch = cell.contentView.viewWithTag(5) as? UISwitch
            {
                tutorialSwitch.addTarget(self, action: Selector("switchIsChanged:"), forControlEvents: UIControlEvents.ValueChanged)
                
                var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
                
                if let tutorialMode: AnyObject  = userDefaults.valueForKey("TutorialMode")
                {
                    tutorialSwitch.setOn(tutorialMode as! Bool, animated: false)
                }


            }
            
            
            
            return cell
            
        case 2:
            let cell = tableView.dequeueReusableCellWithIdentifier("RefreshCellIdentifier", forIndexPath: indexPath) as! UITableViewCell
            
            return cell
            
        default: return UITableViewCell .alloc()
        }
    }
    
}
