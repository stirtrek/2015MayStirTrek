//
//  SpeakersViewController.swift
//  stirtrekconfapp
//
//  Created by PARAG JOSHI on 4/15/15.
//  Copyright (c) 2015 APJ Endeavor LLC. All rights reserved.
//

import Foundation
import UIKit


class SpeakersViewController: UITableViewController {
    
    @IBOutlet var tableview: UITableView!
    
    func refreshData(recognizer: UITapGestureRecognizer) {
        DataManager.getSessionDataFromStirTrekWithSuccess { (sessionData) -> Void in
            
            var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
            
            userDefaults.setValue(true, forKey: "ReloadSpeakersView")
            userDefaults.setValue(true, forKey: "ReloadSessionsView")
            userDefaults.setValue(true, forKey: "ReloadTracksView")
            userDefaults.setValue(true, forKey: "ReloadSponsorsView")
            
            self.tableview.reloadData()
            
        }
        
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var  twoFingerTap = UITapGestureRecognizer(target: self , action: Selector("refreshData:"))
        twoFingerTap.numberOfTouchesRequired = 2
        
        self.tableView.addGestureRecognizer(twoFingerTap)

        
        var userdefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
        
        if let sessionsCachedData: AnyObject = userdefaults.objectForKey("SessionData")
        {
            // We have cached data
            if sessionsData == nil
            {
                if let  sessionsDataDictionary = NSKeyedUnarchiver.unarchiveObjectWithData(sessionsCachedData as! NSData) as? NSDictionary{
                    sessionsData = sessionsDataDictionary
                }
            }
            self.tableview.reloadData()
        }
        else
        {
    
        DataManager.getSessionDataFromStirTrekWithSuccess { (sessionData) -> Void in
            
            
            // Set key to false if true as we have already loaded fresh data
            var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
            
            
            if let reloadThisView: AnyObject  = userDefaults.valueForKey("ReloadSpeakersView")
            {
                if reloadThisView as! Bool  == true
                {
                    userDefaults.setValue(false, forKey: "ReloadSpeakersView")
                    
                }
            }

           
     
            
            self.tableview.reloadData()
            
        }
        }
        
    }
    
    override func viewDidAppear(animated: Bool) {
        var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
        
        if let reloadThisView: AnyObject  = userDefaults.valueForKey("ReloadSpeakersView")
        {
            if reloadThisView as! Bool  == true
            {
                self.tableview.reloadData()
                userDefaults.setValue(false, forKey: "ReloadSpeakersView")
            }
        }
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Table View
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
       return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let sessions = sessionsData {
            if let timeSlots = sessions["Speakers"] as! NSArray? {
                return timeSlots.count
            }
        }
        return 1
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("SpeakerCellIdentifier", forIndexPath: indexPath) as! UITableViewCell
        self.configureCell(cell, atIndexPath: indexPath)
        return cell
    }
    
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return false
    }
    
    func configureCell(cell: UITableViewCell, atIndexPath indexPath: NSIndexPath) {
        
        var sessionName : String?
        var sessionAbstract : String?
        var imageUrl : String?
        
        if let sessions = sessionsData {
            
            if let timeSlots = sessions["Speakers"] as? NSArray {
                
                
                        sessionName = timeSlots[indexPath.row]["Name"] as? String
                        sessionAbstract = timeSlots[indexPath.row]["Bio"] as? String
                        imageUrl = timeSlots[indexPath.row]["ImageUrl"] as? String
                        
                
            }
        }
        
        
        cell.textLabel!.text = sessionName
        cell.detailTextLabel!.text = sessionAbstract
        
        if let url: String = imageUrl {
            if let urlValue = NSURL(string: url)
            {
                
                let downloadQueue = dispatch_queue_create("com.yourcompanyname.asyncImagesStirTrek",nil)
                dispatch_async(downloadQueue){
                    
                    var data = NSData(contentsOfURL: urlValue)
                    
                    var image: UIImage?
                    if (data != nil){
                        image = UIImage(data: data!)
                    }
                    dispatch_async(dispatch_get_main_queue()){
                        cell.imageView!.contentMode = UIViewContentMode.ScaleAspectFit
                        //                cell.imageView!.hnk_setImageFromURL(NSURL(string: url)!)
                        cell.imageView!.image = image

                    }
                }
                
//            if let data = NSData(contentsOfURL:urlValue) {
//                cell.imageView!.contentMode = UIViewContentMode.ScaleAspectFit
////                cell.imageView!.hnk_setImageFromURL(NSURL(string: url)!)
//                cell.imageView!.image = UIImage(data: data)
//            }
            }
        }
    
    }
    
}

