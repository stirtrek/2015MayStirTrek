//
//  SponsorsViewController.swift
//  stirtrekconfapp
//
//  Created by PARAG JOSHI on 4/15/15.
//  Copyright (c) 2015 APJ Endeavor LLC. All rights reserved.
//

import Foundation
import UIKit

class SponsorsViewController: UITableViewController {
    
    @IBOutlet var tableview: UITableView!
    
    
    func refreshData(recognizer: UITapGestureRecognizer) {
        DataManager.getSessionDataFromStirTrekWithSuccess { (sessionData) -> Void in
            
            var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
            
            userDefaults.setValue(true, forKey: "ReloadSpeakersView")
            userDefaults.setValue(true, forKey: "ReloadSessionsView")
            userDefaults.setValue(true, forKey: "ReloadTracksView")
            userDefaults.setValue(true, forKey: "ReloadSponsorsView")
            self.tableview.reloadData()
            
        }
        
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var  twoFingerTap = UITapGestureRecognizer(target: self , action: Selector("refreshData:"))
        twoFingerTap.numberOfTouchesRequired = 2
        
        self.tableView.addGestureRecognizer(twoFingerTap)

        // Do any additional setup after loading the view, typically from a nib.
        var userdefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
        
        if let sessionsCachedData: AnyObject = userdefaults.objectForKey("SessionData")
        {
            // We have cached data
            if sessionsData == nil
            {
                if let  sessionsDataDictionary = NSKeyedUnarchiver.unarchiveObjectWithData(sessionsCachedData as! NSData) as? NSDictionary{
                    sessionsData = sessionsDataDictionary
                }
            }
            self.tableview.reloadData()
        }
        else
        {

        DataManager.getSessionDataFromStirTrekWithSuccess { (sessionData) -> Void in
            // Set key to false if true as we have already loaded fresh data
            var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!
            
            if let reloadThisView: AnyObject  = userDefaults.valueForKey("ReloadSponsorsView")
            {
                if reloadThisView as! Bool  == true
                {
                    userDefaults.setValue(false, forKey: "ReloadSponsorsView")
                    
                }
            }
            

            self.tableview.reloadData()
            
        }
        }
        
    }
    
    
    override func viewDidAppear(animated: Bool) {
        var userDefaults = NSUserDefaults.standardUserDefaults()
        
        if let reloadThisView: AnyObject  = userDefaults.valueForKey("ReloadSponsorsView")
        {
            if reloadThisView as! Bool  == true
            {
                self.tableview.reloadData()
                userDefaults.setValue(false, forKey: "ReloadSponsorsView")
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Table View
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let sessions = sessionsData {
            if let timeSlots = sessions["Sponsors"] as! NSArray? {
                return timeSlots.count
            }
        }
        return 1
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("SponsorCellIdentifier", forIndexPath: indexPath) as! UITableViewCell
        self.configureCell(cell, atIndexPath: indexPath)
        return cell
    }
    
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return false
    }
    
    func configureCell(cell: UITableViewCell, atIndexPath indexPath: NSIndexPath) {
        
        var sessionName : String?
        var sessionAbstract : String?
        var imageUrl : String?
        
        if let sessions = sessionsData {
            
            if let timeSlots = sessions["Sponsors"] as? NSArray {
                
                
                sessionName = timeSlots[indexPath.row]["Name"] as? String
                sessionAbstract = timeSlots[indexPath.row]["URL"] as? String
                imageUrl = timeSlots[indexPath.row]["LogoUrl"] as? String
                
                
            }
        }
        
        
        cell.textLabel!.text = sessionName
        cell.detailTextLabel!.text = sessionAbstract
        
        if let url: String = imageUrl {
            let urlString = "http://stirtrek.com\(url)"
            if let urlValue = NSURL(string: urlString)
            {
                
                let downloadQueue = dispatch_queue_create("com.yourcompanyname.asyncImagesStirTrekSponsor",nil)
                dispatch_async(downloadQueue){
                    
                    var data = NSData(contentsOfURL: urlValue)
                    
                    var image: UIImage?
                    if (data != nil){
                        image = UIImage(data: data!)
                    }
                    dispatch_async(dispatch_get_main_queue()){
                        cell.imageView!.contentMode = UIViewContentMode.ScaleAspectFit
                        //                cell.imageView!.hnk_setImageFromURL(NSURL(string: url)!)
                        cell.imageView!.image = image
                        
                    }
                }
            }
        }
        
    }
    
}


