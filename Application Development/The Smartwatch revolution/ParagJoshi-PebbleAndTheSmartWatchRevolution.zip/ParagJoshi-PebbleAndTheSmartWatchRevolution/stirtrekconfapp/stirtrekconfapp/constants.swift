//
//  constants.swift
//  stirtrekconfapp
//
//  Created by PARAG JOSHI on 4/15/15.
//  Copyright (c) 2015 APJ Endeavor LLC. All rights reserved.
//

import Foundation

var sessionsData: NSDictionary? = nil
var iosFilePath = "/Library/Caches/sessionsData.json"


