//
//  utils.swift
//  stirtrekconfapp
//
//  Created by PARAG JOSHI on 4/17/15.
//  Copyright (c) 2015 APJ Endeavor LLC. All rights reserved.
//

import Foundation

class utils
{
    
    
    
    class func updateWatchDisplay(){
        NSLog("Update Watch method fired")
        
        // Check May 1st as Stir Trek date
        
        var date1String = "05/01/2015"
        
        var favoritesMutableArray = NSMutableArray()
        
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "MM/dd/YYYY"
        
        var connectedWatch: PBWatch? = PBPebbleCentral.defaultCentral().lastConnectedWatch()
        
        
        
        
        //var dateOfConference = dateFormatter.dateFromString(dateString)
        
        
        var today = NSDate()
        var timeSlotId = 99
        var nextTimeSlotId = 99
        
        let date2String = dateFormatter.stringFromDate(today)
        
        var proceed = false
        
        var userDefaults = NSUserDefaults(suiteName: "group.com.yourcompanyname.StirTrekConfApp") as NSUserDefaults!        
        
        
        if let tutorialMode: AnyObject  = userDefaults.valueForKey("TutorialMode")
        {
            if tutorialMode as! Bool  == true
            {
                
                proceed = true
            }
        }
        
        
        if let favoritesData: AnyObject = userDefaults.objectForKey("FavoritesData")
        {
            // We have cached favorites
            if let  favoritesMutableArrayFromCache = NSKeyedUnarchiver.unarchiveObjectWithData(favoritesData as! NSData) as? NSMutableArray{
                favoritesMutableArray = favoritesMutableArrayFromCache
                
            }
        }

        
        if date1String == date2String ||  proceed == true {
            NSLog("Equal dates")
            
            let  dateFormatter2 = NSDateFormatter()
            dateFormatter2.dateFormat = "hh:mm a"
            
            if let sessions = sessionsData {
                
                if let timeSlots = sessions["TimeSlots"] as? NSArray {
                    
                    
                    var timeSlotsSortedList = timeSlots.sortedArrayUsingComparator({ (dict1, dict2) -> NSComparisonResult in
                        let  dateFormatter = NSDateFormatter()
                        dateFormatter.dateFormat = "hh:mm a"
                        
                        let t1 = dict1 as! NSDictionary
                        let t2 = dict2 as! NSDictionary
                        let date1 = dateFormatter.dateFromString(t1["StartTime"] as! String)
                        let date2 = dateFormatter.dateFromString(t2["StartTime"] as! String)
                        
                        return date1!.compare(date2!)
                    })
                    
                    
                    var counter = 0
                    for timeSlot in timeSlotsSortedList
                    {
                        let date1 = dateFormatter2.dateFromString(timeSlot["StartTime"] as! String)
                        let date2 = dateFormatter2.dateFromString(timeSlot["EndTime"] as! String)
                        let nowTime = dateFormatter2.dateFromString(dateFormatter2.stringFromDate(NSDate()))
                        
                        if date1?.compare(nowTime!) == NSComparisonResult.OrderedAscending &&
                            date2?.compare(nowTime!) == NSComparisonResult.OrderedDescending
                        {
                            //We have found our timeslot
                            timeSlotId = timeSlot["Id"] as! Int
                        }
                        
                        if timeSlotId != 99
                        {
                        if date1?.compare(nowTime!) == NSComparisonResult.OrderedDescending
                            
                        {
                            
                            //We have found our timeslot
                            nextTimeSlotId = timeSlot["Id"] as! Int
                            
                            
                            // In between sessions times
                            if timeSlotId == 99 {
                                timeSlotId = timeSlotsSortedList[counter-1]["Id"] as! Int
                            }
                            break
                        }
                        }
                        counter++
                    }
                    
                    
                }
                
                if let sessionArray = sessions["Sessions"] as? NSArray{
                    
                    var sessionName = ""
                    var nextSessionName = ""
                    
                    if timeSlotId != 99
                    {
                        
                        let resultPredicate = NSPredicate(format: "TimeSlotId = \(timeSlotId)")
                        
                        
                        // We find favorites tagged first
                        // If no favorites then we take first session and show it
                        
                        var filteredSessions = sessionArray.filteredArrayUsingPredicate(resultPredicate)
                        
                        for session in filteredSessions{
                            if let sessionId  = session["Id"] as? Int
                            {
                                if favoritesMutableArray.containsObject(sessionId)
                                {
                                    if !sessionName.isEmpty
                                    {
                                        sessionName = sessionName + ", "
                                    }
                                    sessionName = sessionName + (session["Name"] as? String)!
                                }
                            }
                        }
                        
                        if sessionName.isEmpty && filteredSessions.count > 0
                        {
                            sessionName = (filteredSessions[0]["Name"] as? String)!
                        }
                    }
                    
                    if nextTimeSlotId != 99
                    {
                        let resultPredicate2 = NSPredicate(format: "TimeSlotId = \(nextTimeSlotId)")
                        
                        var filteredSessions2 = sessionArray.filteredArrayUsingPredicate(resultPredicate2)
                        
                        
                        
                        for session in filteredSessions2{
                            if let sessionId  = session["Id"] as? Int
                            {
                                if favoritesMutableArray.containsObject(sessionId)
                                {
                                    if !nextSessionName.isEmpty
                                    {
                                        nextSessionName = nextSessionName + ", "
                                    }
                                    nextSessionName = nextSessionName + (session["Name"] as? String)!
                                }
                            }
                        }
                        
                        if nextSessionName.isEmpty && filteredSessions2.count > 0
                        {
                            nextSessionName = (filteredSessions2[0]["Name"] as? String)!
                        }
                    }
                    else if nextTimeSlotId == 99 && timeSlotId != 99
                    {
                        nextSessionName = "Conference Over!"
                    }
                    else if nextTimeSlotId == 99 && timeSlotId == 99
                    {
                        sessionName = "Stir Trek"
                        nextSessionName = "May 1st 2015"
                    }
                    
                    if count(sessionName) > 30
                    {
                        sessionName = sessionName.substringWithRange(Range<String.Index>(start: sessionName.startIndex, end: advance(sessionName.startIndex,30)))
                    }
                    
                    if count(nextSessionName) > 30
                    {
                        nextSessionName = nextSessionName.substringWithRange(Range<String.Index>(start: nextSessionName.startIndex, end: advance(nextSessionName.startIndex,30)))
                    }
                    
                    // Push update to watch
                    /* ... */
                    
                    if let watch = connectedWatch
                    {
                        NSLog("Last connected watch: %@", watch)
                        
                        var update: NSDictionary = [0:sessionName,1:nextSessionName]
                        
                        var myAppUUIDbytes: uuid_t
                        var myAppUUID = NSUUID(UUIDString: "Unique UUID here")!
                        
                        // data object with appropriate size:
                        var data = NSMutableData(length: 16)
                        // fill the bytes from the UUID:
                        myAppUUID.getUUIDBytes(UnsafeMutablePointer(data!.mutableBytes))
                        
                        
                        connectedWatch?.appMessagesPushUpdate(update as! [NSObject : AnyObject], onSent: { (watch, objectAny, error) -> Void in
                            if error != nil  {
                                NSLog("error: %@",error)
                            }
                            else {
                                NSLog("Success in sending message")
                            }
                        })
                        
                        
                        
                    }
                    /* ... */
                    
                }
                
                
            }
            
            
            
        }else
        {
            // Push update to watch
            /* ... */
            connectedWatch = PBPebbleCentral.defaultCentral().lastConnectedWatch()
            if let watch = connectedWatch
            {
                NSLog("Last connected watch: %@", watch)
                
                var update: NSDictionary = [0:"Stir Trek",1:"May 1st 2015"]
                
                var myAppUUIDbytes: uuid_t
                var myAppUUID = NSUUID(UUIDString: "Unique UUID here")!
                
                // data object with appropriate size:
                var data = NSMutableData(length: 16)
                // fill the bytes from the UUID:
                myAppUUID.getUUIDBytes(UnsafeMutablePointer(data!.mutableBytes))
                
                
                connectedWatch?.appMessagesPushUpdate(update as! [NSObject : AnyObject], onSent: { (watch, objectAny, error) -> Void in
                    if error != nil  {
                        NSLog("error: %@",error)
                    }
                    else {
                        NSLog("Success in sending message")
                    }
                })
                
                
                
            }
            /* ... */
        }
        
    }
    
}
