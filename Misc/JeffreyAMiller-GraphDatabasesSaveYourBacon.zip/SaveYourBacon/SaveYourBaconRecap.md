<!-- .slide id="recap" -->

# Recap

***
***

# Graph Strategies
## for
# Software Success

***
# Strategy #1:

<blockquote class="fragment roll-in transitionMedium">
<h1>Model</h1>
<h2>what you want to</h2>
<h1>Master</h1>
</blockquote>

***

# Steps to build your model

---

# Gather your data<br />far and wide!

<ul class="largeBullets">
<li>ALM tools (TFS, etc.)</li>
<li>Bug trackers</li>
<li>Agile/Scrum trackers</li>
<li>Source control</li>
<li>Databases, ERDs, and metadata</li></ul>

---
<!-- .slide: data-advance-after="800" -->

# <!-- .element: class="fragment visible" data-advance-after="800" -->Don't just stop there!

<ul class="largeBullets fragment fade transitionShort">
<li>User stories</li>
<li>Back log</li>
<li>Requirements documents</li>
<li>Test cases</li></ul>

---
<!-- .slide: data-advance-after="800" -->

# <!-- .element: class="fragment visible" data-advance-after="800" -->Dig even deeper!

<ul class="largeBullets fragment fade transitionShort">
<li>Sharepoint documents</li>
<li>Organization chart</li>
<li>Enterprise architecture</li></ul>

---
<!-- .slide: data-advance-after="800" -->

# <!-- .element: class="fragment visible" data-advance-after="800" -->Comb your code base!

<ul class="largeBullets fragment fade transitionShort">
<li>Style sheets</li>
<li>JavaScript files</li>
<li>MVC views</li>
<li>Business objects</li></ul>

---
<!-- .slide: data-advance-after="800" -->

# <!-- .element: class="fragment visible" data-advance-after="800" -->Tackle your test plans!

<ul class="largeBullets fragment fade transitionShort">
<li>Automated tests</li>
<li>Integration tests</li>
<li>Unit test</li>
<li>Features</li></ul>

---

## Enlist everyone!
	
* DBAs
* QAs
* Devs
* BAs

***

# Strategy #2:

<blockquote class="fragment roll-in transitionMedium">
<h1>Connect</h1>
<h2>what you want to</h2>
<h1>Control</h1>
</blockquote>

*** <!-- .slide: style="text-align: left;" -->
# Now, go connect things!
# &nbsp;
# THE END

***

# Resources

* [neo4j.com](neo4j.com)
* Free e-book: Graph Databases - [graphdatabases.com](http://graphdatabases.com/)
<div style="zoom: 0.5;">
![](images/cropped-graphdatabases_cover390x5121.png)
</div>

## Contact: [jmiller@icct.com](jmiller@icct.com)