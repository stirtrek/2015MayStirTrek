# Six Degrees of Dev'n

#### How

## Graph Databases

#### Can

## Save Your Bacon

### (Or Neo4j for Dev Teams)

<small>Created by <a href="http://jmill.net/connect">Jeffrey A. Miller</a> / <a href="http://twitter.com/xagronaut">@xagronaut</a></small>
*** <!-- .slide: data-transition="zoom" data-background="images/Six_degrees_of_separation.svg" data-advance-after="2500" -->

# We're all connected...<!-- .element: class="fragment visible bandedHeading" style="margin-top: 80px;" data-fragment-index="1" data-advance-after="1500" -->
# more than you think.<!-- .element: class="fragment bandedHeading" style="transition-duration: 2s; margin-top: 70px;" data-fragment-index="2"-->

***

# Six Degrees

## is it really TRUE?

## Everyone on the Planet

---

## can be

# CONNECTED?

---

### By only

# SIX RELATIONSHIPS?

***

# It's a popular meme...

## (as [Wikipedia will verify](http://en.wikipedia.org/wiki/Six_degrees_of_separation))

Note: Its exact science and origin is more unclear - an author from the turn of the 20th century, a play from the 1990's...even Marconi has been credited by some. Famed researcher Stanley Milgram performed experiments to test the theory.

---
<!-- .slide: data-advance-after="2000" -->

# It's even a cool party game&hellip;
<!-- .element: class="fragment visible" data-advance-after="1500" -->

# about BACON!<!-- .element: class="fragment fade" data-advance-after="2000" -->

## <!-- .element: class="fragment fade" -->(err&hellip;*Kevin*&#160;&#160;Bacon)
---
![](images/Kevin_Bacon.jpg)
***
***
# Where you Work
---
# Bonzai Bacon
# and
# Banana Cabana
## (.com)
***
# Meet *Kevin*, the CSS guy
---
![](images/Kevin_Bacon_funny2.png)
---
## It's almost go live time&hellip;

## <!-- .element: class="fragment" -->I know!

## <!-- .element: class="fragment" -->Let's have<br />Kevin<br />fix the CSS!
---
## Just one problem&hellip;

# Kevin doesn't know<br />the code base
---
# Kevin doesn't know<br />Visual Studio
---
# Kevin's probably thinking...

<ul class="largeBullets fragment fade">
<li>How do I find all the references?</li>
<li>Where do I start??</li></ul>
***
<!-- .slide: class="advanceAfterMedium" -->
# But then I start thinking...
## Hey, no sweat!
<ul class="largeBullets fragment">
<li>Just search the web project&hellip;<br />using regular expressions</li></ul>
***
<!-- .slide: class="advanceAfterMedium" -->
# Hi, Kevin&hellip;I can help!

## <!-- .element: class="fragment" -->(Kevin looks nervous)
---
<!-- .slide: class="advanceAfterMedium" -->
# All you need is regular expressions...

## <!-- .element: class="fragment" -->(Kevin looks confused)
---
<!-- .slide: class="advanceAfterMedium" -->
# &hellip;and a graph database!

## <!-- .element: class="fragment" -->(Kevin looks *really*&#160;&#160;confused)
***
# These are not new problems
***
<!-- .slide: class="advanceAfterMedium" -->
## Every day problems:

<ul class="largeBullets fragment fade">
<li>Devs make crazy changes</li>
<li>DBAs "optimize" the schema</li>
<li>Bugs go undetected</li>
<li>Fixes are costly</li></ul>

Note: the cost of a defect goes up quickly the longer it exists, but it's not just money and time. Opportunity cost means I can't develop a feature if I'm occupied fixing a bug. Reputation cost means that our credibility takes a hit every time a major bug appears.
***
# But what if&hellip;?

## locate trouble spots?
## predict problems?
## prevent defects?
---
# Graph databases can help!
***
# What's a Graph Database?
---
## Tables, rows, columns &mdash; What else is there?
***
# What's a *Graph?*

<blockquote class="fragment roll-in transitionMedium" style="font-size: 1.4em;">
In mathematics, and more specifically in graph theory, a directed graph (or digraph) is a graph, or set of nodes connected by edges, where the edges have a direction associated with them.
</blockquote>
***
# Can I see one?

![](images/Directed.svg)<!-- .element: class="nodeDiagram" style="zoom: 2.0;" -->
***
# What's a Graph <em>Database?</em>

<blockquote class="fragment roll-in transitionShort" style="font-size: 1.4em;">
	a database designed to efficiently store and model items (nodes) and the relationships (edges) between them
</blockquote>

---
# Testing Domain
![](images/TestingDomain.svg)<!-- .element: class="nodeDiagram" style="zoom: 1.2;" -->
---
# Human Domain
![](images/HumanNodeDomain.svg)<!-- .element: class="nodeDiagram" style="zoom: 1.3;" -->
---
# Domains can overlap
![](images/Domains_Human_and_Process.svg)<!-- .element: class="nodeDiagram" style="zoom: 0.8;" -->
---
# Process Domain (w/ Testing)
![](images/ProcessDomainSlimArrows.svg)<!-- .element: class="nodeDiagram" style="zoom: 1.0;" -->
---
# Knowledge Domain
![](images/Knowledge_NodeDomain.svg)<!-- .element: class="nodeDiagram" style="zoom: 1.5;" -->
***
# Sample Process
![](images/ProcessNodeDomain_old.svg)<!-- .element: class="nodeDiagram" style="zoom: 1.3;" -->
---
# Process (evolved)
![](images/ProcessNodeDomain.svg)<!-- .element: class="nodeDiagram" style="zoom: 0.8;" -->
---
# Web domain
![](images/WebNodeDomain_w_o_NodeDomain.svg)<!-- .element: class="nodeDiagram" style="zoom: 2.0;" -->
***
# What's <em>different</em> about a

# Graph Database

## (Graph vs. Relational)
---
# Relationships are

# First-class citizens

## (no more many-to-many tables!)
---
# "AFFECTS" relationship
![](images/AFFECTS_Relationship_Simple.svg)<!-- .element: class="nodeDiagram" style="zoom: 2.0;" -->
---
# Graph databases are
# easy to change

It's easy to add new kinds of relationships

Nodes can have more than one label

Adding properties is very easy
---
# No recursive SQL queries

## Example: Product categories

* Books
	* E-books
	* Print books
	* Out-of-print books
* Electronics
	* Car audio
	* Computers
***
# OK, great!

# a graph database...
***
# How does that help my team?
***
# Visual models convey lots
# of information quickly
---
# Think visually
![](images/TestingDomain.svg)<!-- .element: class="nodeDiagram" style="zoom: 1.2;" -->
---
# See what's missing
![](images/Human_and_Process_NodeDomains.svg)<!-- .element: class="nodeDiagram" style="zoom: 0.8;" -->
*** <!-- .slide: data-transition="zoom" data-background="images/Six_degrees_of_separation.svg" -->

# <!-- .element: class="bandedHeading" -->News flash...
*** <!-- .slide: data-transition="zoom" data-background="images/Six_degrees_of_separation.svg" -->

# You are dis-connected!!<!-- .element: class="bandedHeading" data-fragment-index="1"-->

# <!-- .element: class="fragment bandedHeading" style="transition-duration: 2s; margin-top: 120px;" -->more than you think!
***
<!-- .slide class="advanceAfterMedium" -->
# Disconnected...

<ul class="largeBullets fragment fade advanceAfterLong">
<li>your <em>CODE</em>!</li>
<li>your <em>TEAM</em>!</li>
<li>your <em>PROCESS</em>!</li></ul>

# <!-- .element: class="fragment fade-in" -->more than you think!
***
## Don't believe me?
---
# Can you answer?

<ul class="largeBullets fragment fade">
<li class="fragment fade">How much test coverage do I have?<span class="fragment fade">&#160;by <em>feature</em>, by <em>release</em>, by <em>check-in</em>?</span></li>
<li class="fragment fade">If I change a style sheet, which parts of the app will I need my users to review?</li>
<li class="fragment fade">Who has worked on a <em>feature</em>?</li>
<li class="fragment fade">What <em>features</em> have the most code thrash?</li>
<li class="fragment fade">What <em>features</em> have the most defects?</li></ul>

Note: intersperse images of basic graphs that answer the questions.
***
# Why not use a spreadsheet?

<ul class="largeBullets fragment fade">
<li>tab for every type of data</li>
<li>tab for every kind of relationship</li>
<li>enjoy creating pivot tables with VLOOKUPs?</li>
<li>spreadsheets live in *SharePoint*?</li></ul>
***
# Meet Neo4j

## Your Open Source Graph Database
***
# CYPHER =<br />SQL for Graphs
***
<!-- .slide: class="advanceAfterShort" -->
# Keywords and commands

<ul class="largeBullets fragment fade">
<li>CREATE</li>
<li>MATCH and RETURN</li>
<li>MERGE and SET</li>
<li>DELETE</li></ul>
---
# CREATE

## inserts a new node

<pre data-lang="cypher" class="largeCodeSample stretch">// Create and return a new node
CREATE (h:Hero { name: "Iron Man" }) RETURN h
</pre>
***
<!-- .slide: class="advanceAfterShort" -->
# MATCH

## (Pattern matching)

<ul class="largeBullets fragment fade">
<li>seeks match on all properties in match expression</li>
<li>WHERE clauses filter even more</li></ul>
***
# Show me everything Goldilocks!
<pre data-lang="cypher" class="largeCodeSample stretch">// All nodes
MATCH n
RETURN n;</pre>
---
# Pattern matching
<pre data-lang="cypher" class="largeCodeSample stretch">// match first 25 nodes of any kind
// with a 'firstName' property == "John"
MATCH (n { firstName: "John" })
RETURN n LIMIT 25;
</pre>
---
# Relationship direction syntax

## "ASCII art" arrow syntax:

<table style="font-size: 1.4em;">
	<thead>
		<tr><th>Purpose</th><th>Code</th></tr>
	</thead>
	<tbody>
		<tr><td>Direction</td><td><code>(a)<strong>--&gt;</strong>(b)</code></td></tr>
		<tr><td>Hops</td><td><code>(a)-[*1..2]-&gt;(b)</code></td></tr>
		<tr><td>Label</td><td><code>(a)-[:KNOWS]-&gt;(b)</code></td></tr>
	</tbody>
</table>
---
# Add a WHERE clause
<pre data-lang="cypher" class="largeCodeSample stretch">// match first 25 nodes of any kind with a
// 'name' property == "John"
// who has at least 3 siblings
MATCH (n { name: "John" })
WHERE n.siblingCount > 2
RETURN n LIMIT 25;</pre>

***
# MERGE and SET
## (aka "UPSERT")
<pre data-lang="cypher" class="largeCodeSample stretch">// Create and/or update a node, then return it
MERGE (h:Hero { name: "The Hulk" })
SET description = "always angry, sometimes green"
RETURN h
</pre>
***
# DEMO!!!
***
Scenario

## Black Friday
# Bonzai Bonus Bacon
# Bonanza
---
## Amazon.com

# Buy 1 Bacon
# Get 2nd Bacon 50% off

## Score!
***
# Requirement

## As a Bacon Seller
## I want to disable a product
## So I can prevent backorders 
---
## Big problem

# Bacon backorders<br />are a buzzkill
***
# Let's start the project

<pre data-lang="cypher" class="largeCodeSample stretch">// Start the big project
MATCH (pmo:Group { name: "Project Management (PMO)" })
MERGE (bbbp:Project { name: "Bonus Bacon Bonanza" })
MERGE (bpt:Group { name: "Big Push team" })
MERGE (pmo)-[:MANAGES]->(bbbp)
MERGE (bpt)-[:REPORTS_TO]-(pmo)
MERGE (bpt)-[:WORKS_ON]-(bbbp)
RETURN pmo, bpt, bbbp;</pre>
***
## Result
![](images/BigPushProject.svg)<!-- .element: class="nodeDiagram" style="zoom: 2.0;" -->
***
Scenario

# The big push
# (Bring in the Consultants!)
***
# Battlestations! to the CSV!
<pre data-lang="cypher" class="largeCodeSample stretch">// Load the new consultants
LOAD CSV WITH HEADERS FROM
"http://localhost/SaveYourBacon/import/BigPushTeam.txt"
AS csvLine FIELDTERMINATOR '\t'
MATCH (bpt:Group { name: csvLine.team })
MATCH (pgrp:Group { name: csvLine.group })
MATCH (cons:Organization { name: "Zippity, Inc." })
MATCH (role:Role { name: csvLine.role })
MERGE (mbr:Person { name: csvLine.consultant })
MERGE (mbr)-[:MEMBER_OF]->(bpt)
MERGE (mbr)-[:EMPLOYED_BY]->(cons)
MERGE (mbr)-[:MEMBER_OF]->(pgrp)
MERGE (mbr)-[:WORKS_AS]->(role)
RETURN DISTINCT csvLine, bpt, pgrp, cons, mbr, role;</pre>
---
# Result: Chaos?
![](images/ConsultantChaos.svg)<!-- .element: class="nodeDiagram" style="zoom: 0.8;" -->
---
# Just the team folks!
<pre data-lang="cypher" class="largeCodeSample stretch">// Just the team folks!
MATCH (bpt:Group { name: "Big Push team" })
OPTIONAL MATCH (bpt)-[]-(n)
RETURN DISTINCT bpt, n;</pre>
---
# That's better
![](images/JustTheTeam.svg)<!-- .element: class="nodeDiagram" style="zoom: 1.0;" -->
***
# Remember Kevin?
---
# Which is easier?

## Combing through HTML&hellip;

<pre><!-- .element: class="largeCodeSample" --><code class="html">
&lt;link rel="stylesheet" href="some-styles.css" /&gt;
&lt;!-- &hellip; or in ASP.NET MVC&hellip; --&gt;
&lt;link rel="stylesheet" href='@Url.Content("~/Styles/some-styles.css")' /&gt;
</pre>
---
# Or this?

<pre data-lang="cypher" class="largeCodeSample stretch">// MATCH CSS files with MVC views
MATCH (c:CssFile)-[r]-(v:MvcView)
RETURN DISTINCT c, v
</pre>

***
<!-- .slide: id="exampleQueries" -->
# Example queries
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Knowledge domain
MATCH (n:Knowledge)
RETURN n;</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Process domain
MATCH (n:Process)
RETURN n;
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Testing domain
MATCH (n:Testing)
RETURN n;
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Everything connected to MVC View
MATCH (n:Web { name: "MvcView" })-[r]-(m)
RETURN n, r;</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Technical domain
MATCH (n:Technical) RETURN n;</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Web domain
MATCH (n:Web) RETURN n;
</pre>
---
# Result
![](images/WebNodeDomain_w_o_NodeDomain.svg)<!-- .element: class="nodeDiagram" style="zoom: 2.0;" -->
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Return non-metadata nodes
MATCH (n)-[r:USES]->()
WHERE NOT(n:NodeType)
RETURN r;
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Testing CSS changes
// test cases that need to run for CSS changes
MATCH (t:TestCase)-[]-(vw:MvcView)-[]-(css:CssFile)
RETURN t, vw, css
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Data: Testing CSS changes
MATCH (t:TestCase)-[]-(vw:MvcView)-[]-(css:CssFile)
RETURN t.name, vw.name, css.name
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Test cases for requirements
MATCH (tc:TestCase)-[]-(ts:TestSuite)-[]-(req:Requirement),
	(tc)-[]-(req)
RETURN DISTINCT tc, ts, req
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Views missing test cases?
MATCH (vw:MvcView)
OPTIONAL MATCH (vw)-[r]-(tc:TestCase)
RETURN vw, r;
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Data: Views missing test cases?
MATCH (vw:MvcView)
OPTIONAL MATCH (vw)-[r]-(tc:TestCase)
WHERE r = NULL
RETURN vw.name;
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Data: Test Case count by View
MATCH (vw:MvcView)
OPTIONAL MATCH (vw)-[r]-(tc:TestCase)
RETURN vw.name, COUNT(tc) AS testCaseCount
ORDER BY testCaseCount DESC;
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Find requirements
MATCH (req:Requirement)
RETURN req;</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Find requirements and relationships
MATCH (req:Requirement)
OPTIONAL MATCH(req)-[*1..2]-(n)
RETURN req, n;
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Find requirements and existing relationships
MATCH (req:Requirement)
MATCH (req)-[*1..2]-(n)
RETURN req, n;
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Find MvcViews missing test cases
MATCH (vw:MvcView)
OPTIONAL MATCH (vw)-[r]-(tc:TestCase)
RETURN vw, r;
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Data: Find MvcViews missing test cases
MATCH (vw:MvcView)
OPTIONAL MATCH (vw)-[r]-(tc:TestCase)
WHERE r = NULL
RETURN vw.name;
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Data: Test Case count by MVC View, sorted
MATCH (vw:MvcView)
OPTIONAL MATCH (vw)-[r]-(tc:TestCase)
RETURN vw.name, COUNT(tc) AS testCaseCount
ORDER BY testCaseCount DESC;
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// Find MVC views with 2 or more test cases
MATCH (vw:MvcView)
OPTIONAL MATCH (vw)-[r]-(tc:TestCase)
WITH vw, COUNT(tc) AS testCaseCount
WHERE testCaseCount >= 2
RETURN vw.name, testCaseCount;
</pre>
---
<pre data-lang="cypher" class="largeCodeSample stretch">// MEMBER_OF relationships
MATCH ()-[r:MEMBER_OF]->()
RETURN r;
</pre>
