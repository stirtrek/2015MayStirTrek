package com.sjonsson.demo.restassured;

import org.junit.Test;
import static com.jayway.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sjonsson
 */
public class ProductSearchTest {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    
    private static final String GOOGLE_KEY = TestProperties.get("googleKey");
    private static final String GOOGLE_CX = TestProperties.get("googleCx");
    private static final String SEMANTICS3_KEY = TestProperties.get("semantics3Key");
    
    @Test
    public void goToWebSiteThatSellsBestPhone() {
        
        // Google search for best phone
        // E.g. https://www.googleapis.com/customsearch/v1?q="named best smartphone"&key=AIzaSyAH&cx=0002421:hcpzm&alt=json
        
        String title =        
        given().
                queryParam("q", "\"named best smartphone\"").
                queryParam("alt", "json").
                queryParam("key", GOOGLE_KEY).
                queryParam("cx", GOOGLE_CX).
        when().
                get("https://www.googleapis.com/customsearch/v1").                 
        then().
                statusCode(200).
                body("searchInformation.totalResults", not("0")).
        extract().jsonPath().get("items[0].title");
        log.debug("title: {}", title);
        
        String phoneName = title.substring(0, title.toLowerCase().indexOf(" named "));
        log.debug("phoneName: {}", phoneName);
        
        // Semantics3 search for merchant that sells device
        // https://api.semantics3.com/test/v1/products?q={"search":"LG G3","cat_id":12181}
       
        String productUrl =       
        given().
                queryParam("q", "{\"search\":\"" + phoneName + "\",\"cat_id\":12181}").
                header("api_key", SEMANTICS3_KEY).
        when().
                get("https://api.semantics3.com/test/v1/products").        
        then().
                statusCode(200).
                body("total_results_count", greaterThan(0)).
                body("results[0].sitedetails[1].url", startsWith("http")). 
        extract().jsonPath().get("results[0].sitedetails[1].url"); 
        log.debug("productUrl: {}", productUrl);       
        
        // Web request for product site        

        String html =
        when().
                get(productUrl).
        then().
                statusCode(200).
                body(containsString(phoneName)).
        extract().response().asString();
        
        log.debug("html snipped: {}", html.substring(0,500));        
        
    }

}
