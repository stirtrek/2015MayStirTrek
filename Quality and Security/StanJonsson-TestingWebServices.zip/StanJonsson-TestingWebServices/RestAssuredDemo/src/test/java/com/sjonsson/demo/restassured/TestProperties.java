package com.sjonsson.demo.restassured;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.parsing.Parser;
import java.io.IOException;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sjonsson
 */
public class TestProperties {

    private static final Logger log = LoggerFactory.getLogger(TestProperties.class);
    
    private static final Properties properties = new Properties();
    
    static {
        try {
            properties.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("test.properties"));
            RestAssured.registerParser("application/octet-stream", Parser.JSON);
        }
        catch (IOException ioe) {
            log.error("Unable to load properties", ioe);
        }
    }
    
    public static String get(String key) {
        return properties.getProperty(key);
    }
}
