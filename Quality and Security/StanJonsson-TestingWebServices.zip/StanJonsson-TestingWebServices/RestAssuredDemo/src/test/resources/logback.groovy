appender("CONSOLE", ConsoleAppender) {
  encoder(PatternLayoutEncoder) {
    pattern = "%d{HH:mm:ss.SSS} %-5p %t [%F:%L] %m%n"
  }
}
logger("com.sjonsson", DEBUG)
root(WARN, ["CONSOLE"])