'use strict';

var $ = require('jquery');
var multiplication = require('./operators/multiplication');

var doMath = function () {
	var left = parseFloat($("#left").val());
	var right = parseFloat($("#right").val());
	var result = multiplication.multiply(left, right);

	$("#result").text(result);
};

$("#go").on("click", doMath);