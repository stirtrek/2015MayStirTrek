'use strict';

exports.add = function (left, right) {
	return left + right;
};