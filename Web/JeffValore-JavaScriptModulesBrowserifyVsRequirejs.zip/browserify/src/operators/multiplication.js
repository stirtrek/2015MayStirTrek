'use strict';

var addition = require('./addition');

var multiply = function (left, right) {
	var total = 0;

	for(var i = 0; i < right; i++) {
		total = addition.add(total, left);
	}

	return total;
};

exports.multiply = multiply;