require.config({
	paths: {
		"jquery": "jquery-2.1.3.min"
	}
});

require(['jquery', 'operators/addition', 'operators/multiplication'], function ($, addition, multiplication) {
	'use strict';
	
	var doMath = function () {
		var left = parseFloat($("#left").val());
		var right = parseFloat($("#right").val());
		var result = multiplication.multiply(left, right);
	
		$("#result").text(result);
	};
	
	$("#go").on("click", doMath);
});
