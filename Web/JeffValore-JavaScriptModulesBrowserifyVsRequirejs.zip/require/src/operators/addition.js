define([], function () {
	'use strict';
	
	return {
		add: function (left, right) {
			return left + right;
		}
	};
});
