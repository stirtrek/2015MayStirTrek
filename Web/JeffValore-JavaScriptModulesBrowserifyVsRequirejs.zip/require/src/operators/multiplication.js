define(['operators/addition'], function (addition) {
	'use strict';
			
	var multiply = function (left, right) {
		var total = 0;
	
		for(var i = 0; i < right; i++) {
			total = addition.add(total, left);
		}
	
		return total;
	};
	
	return {
		multiply: multiply
	};
});
